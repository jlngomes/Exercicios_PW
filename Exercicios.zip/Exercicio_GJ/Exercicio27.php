<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
      /*27 - Ler um valor e escrever se é positivo, negativo ou zero.*/

     $num3 = 15;
     if ($num3 > 0){
     echo "<p>O número é positivo</p>";
     }else if ($num3 < 0 ){
     echo "<p>O número é negativo</p>";
     }else{
     echo "<p>O número igual a 0 </p>";
     }
     ?>
</body>
</html>