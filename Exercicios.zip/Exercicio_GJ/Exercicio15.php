<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
      /*15 - Ler um valor e escrever se é positivo ou negativo (considere o valor zero como positivo).*/

     $num2 = 15;
     if ($num2 >= 0){
     echo "<p>O número é positivo</p>";
     }else{
      echo "<p>O número é negativo</p>";
     }
    
    ?>
</body>
</html>