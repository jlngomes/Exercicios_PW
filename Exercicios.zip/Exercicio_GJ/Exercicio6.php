<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
 <?php
 /*6) Escreva um algoritmo para ler as dimensões de um retângulo (base e altura), calcular e escrever a
área do retângulo.*/

  $base = 20;
  $altura = 20;
  $area =  ($base * $altura)/2; 
  echo "<p>A área de um triângulo de base " . $base . " e altura " . $altura . " é ". $area. "</p>" ;
 ?>    

</body>
</html>