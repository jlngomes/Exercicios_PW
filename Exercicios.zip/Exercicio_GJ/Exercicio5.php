<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
    
    /* 5) Escreva um algoritmo para ler um valor (do teclado) e escrever (na tela) o seu antecessor.*/

    $num1 = 60;
    $numeroant = $num1 - 1;
    echo "<p>O valor antecessor de  ". $num1 . " é: " . $numeroant. "</p>";
    
    ?>
</body>
</html>